# StreetLightdetection > 2label
https://universe.roboflow.com/streetlight-xs545/streetlightdetection

Provided by a Roboflow user
License: CC BY 4.0

